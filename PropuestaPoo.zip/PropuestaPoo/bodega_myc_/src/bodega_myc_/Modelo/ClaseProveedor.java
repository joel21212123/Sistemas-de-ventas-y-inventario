
package bodega_myc_.Modelo;


public class ClaseProveedor {
    private int id_proveedores;
    private String ruc_proveedores;
    private String nombre_proveedores;
    private String telefono_proveedores;
    private String email_proveedores;

    public ClaseProveedor() {
    }

    public int getId_proveedores() {
        return id_proveedores;
    }

    public void setId_proveedores(int id_proveedores) {
        this.id_proveedores = id_proveedores;
    }

    public String getRuc_proveedores() {
        return ruc_proveedores;
    }

    public void setRuc_proveedores(String ruc_proveedores) {
        this.ruc_proveedores = ruc_proveedores;
    }

    public String getNombre_proveedores() {
        return nombre_proveedores;
    }

    public void setNombre_proveedores(String nombre_proveedores) {
        this.nombre_proveedores = nombre_proveedores;
    }

    public String getTelefono_proveedores() {
        return telefono_proveedores;
    }

    public void setTelefono_proveedores(String telefono_proveedores) {
        this.telefono_proveedores = telefono_proveedores;
    }

    public String getEmail_proveedores() {
        return email_proveedores;
    }

    public void setEmail_proveedores(String email_proveedores) {
        this.email_proveedores = email_proveedores;
    }

    
}
