
package bodega_myc_.ConexionMysql;

import bodega_myc_.Modelo.ClaseMovimientoInventario;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ClaseConsultaMovimientosInventario   {
     private final ConexionClass conexion = new ConexionClass();

    // Registrar movimiento
    public boolean registrar(ClaseMovimientoInventario movimiento) {
        String sql = "INSERT INTO movimientos_inventario (producto_id, tipo_movimientos, "
                   + "cantidad_movimientos, motivo_movimientos, usuario_id) "
                   + "VALUES (?, ?, ?, ?, ?)";
        
        try (Connection con = conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            
            ps.setInt(1, movimiento.getProducto_id());
            ps.setString(2, movimiento.getTipo_movimientos());
            ps.setInt(3, movimiento.getCantidad_movimientos());
            ps.setString(4, movimiento.getMotivo_movimientos());
            ps.setInt(5, movimiento.getUsuario_id());
            
            return ps.executeUpdate() > 0;
        } catch(SQLException e) {
            System.err.println("Error al registrar movimiento: " + e.getMessage());
            return false;
        }
    }

    // Obtener por ID
    public ClaseMovimientoInventario obtenerPorId(int idMovimiento) {
        String sql = "SELECT * FROM movimientos_inventario WHERE id_movimientos_inventario = ?";
        
        try (Connection con = conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            
            ps.setInt(1, idMovimiento);
            
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    ClaseMovimientoInventario movimiento = new ClaseMovimientoInventario();
                    movimiento.setId_movimientos_inventario(rs.getInt("id_movimientos_inventario"));
                    movimiento.setProducto_id(rs.getInt("producto_id"));
                    movimiento.setTipo_movimientos(rs.getString("tipo_movimientos"));
                    movimiento.setCantidad_movimientos(rs.getInt("cantidad_movimientos"));
                    movimiento.setMotivo_movimientos(rs.getString("motivo_movimientos"));
                    movimiento.setFecha_movimientos(rs.getTimestamp("fecha_movimientos"));
                    movimiento.setUsuario_id(rs.getInt("usuario_id"));
                    return movimiento;
                }
            }
        } catch(SQLException e) {
            System.err.println("Error al obtener movimiento: " + e.getMessage());
        }
        return null;
    }

    // Obtener por producto
    public List<ClaseMovimientoInventario> obtenerPorProducto(int idProducto) {
        List<ClaseMovimientoInventario> movimientos = new ArrayList<>();
        String sql = "SELECT * FROM movimientos_inventario WHERE producto_id = ?";
        
        try (Connection con = conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            
            ps.setInt(1, idProducto);
            
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    ClaseMovimientoInventario movimiento = new ClaseMovimientoInventario();
                    movimiento.setId_movimientos_inventario(rs.getInt("id_movimientos_inventario"));
                    movimiento.setProducto_id(rs.getInt("producto_id"));
                    movimiento.setTipo_movimientos(rs.getString("tipo_movimientos"));
                    movimiento.setCantidad_movimientos(rs.getInt("cantidad_movimientos"));
                    movimiento.setMotivo_movimientos(rs.getString("motivo_movimientos"));
                    movimiento.setFecha_movimientos(rs.getTimestamp("fecha_movimientos"));
                    movimiento.setUsuario_id(rs.getInt("usuario_id"));
                    movimientos.add(movimiento);
                }
            }
        } catch(SQLException e) {
            System.err.println("Error al obtener movimientos por producto: " + e.getMessage());
        }
        return movimientos;
    }

    // Obtener todos los movimientos
    public List<ClaseMovimientoInventario> obtenerTodos() {
        List<ClaseMovimientoInventario> movimientos = new ArrayList<>();
        String sql = "SELECT * FROM movimientos_inventario";
        
        try (Connection con = conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            
            while (rs.next()) {
                ClaseMovimientoInventario movimiento = new ClaseMovimientoInventario();
                movimiento.setId_movimientos_inventario(rs.getInt("id_movimientos_inventario"));
                movimiento.setProducto_id(rs.getInt("producto_id"));
                movimiento.setTipo_movimientos(rs.getString("tipo_movimientos"));
                movimiento.setCantidad_movimientos(rs.getInt("cantidad_movimientos"));
                movimiento.setMotivo_movimientos(rs.getString("motivo_movimientos"));
                movimiento.setFecha_movimientos(rs.getTimestamp("fecha_movimientos"));
                movimiento.setUsuario_id(rs.getInt("usuario_id"));
                movimientos.add(movimiento);
            }
        } catch(SQLException e) {
            System.err.println("Error al obtener movimientos: " + e.getMessage());
        }
        return movimientos;
    } 
}
