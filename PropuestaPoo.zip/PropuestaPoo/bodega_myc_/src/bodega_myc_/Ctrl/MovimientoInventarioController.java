package bodega_myc_.Ctrl;

import bodega_myc_.ConexionMysql.ClaseConsultaMovimientosInventario ;
import bodega_myc_.Modelo.ClaseMovimientoInventario;
import bodega_myc_.Vista.MOVIMIENTO_INVENTARIO;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class MovimientoInventarioController implements ActionListener {
    private ClaseMovimientoInventario mod;
    private ClaseConsultaMovimientosInventario  modConsulta;
    private MOVIMIENTO_INVENTARIO frm;
    private int usuarioId;
    
    public MovimientoInventarioController(ClaseMovimientoInventario mod, 
            ClaseConsultaMovimientosInventario   modConsulta, 
            MOVIMIENTO_INVENTARIO frm, int usuarioId) {
        
        this.mod = mod;
        this.modConsulta = modConsulta;
        this.frm = frm;
        this.usuarioId = usuarioId;
        
        this.frm.btnNuevoMovimientoInventario.addActionListener(this);
        this.frm.btnLeerMovimientoInventario.addActionListener(this);
        this.frm.btnModificarMovimientoInventario.addActionListener(this);
        this.frm.btnEliminarMovimientoInventario.addActionListener(this);
        
        frm.txtUsuarioId.setText(String.valueOf(usuarioId));
        frm.txtUsuarioId.setEditable(false);
        frm.txtFechaMovimiento.setText(new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(new Date()));
        frm.txtFechaMovimiento.setEditable(false);
    }
    
    public void iniciar() {
        frm.setTitle("Movimientos de Inventario");
        frm.setLocationRelativeTo(null);
        frm.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == frm.btnNuevoMovimientoInventario) {
            guardarMovimiento();
        } 
        else if (e.getSource() == frm.btnLeerMovimientoInventario) {
            cargarMovimientos();
        }
        else if (e.getSource() == frm.btnModificarMovimientoInventario) {
            actualizarMovimiento();
        }
        else if (e.getSource() == frm.btnEliminarMovimientoInventario) {
            eliminarMovimiento();
        }
    }
    
    private void guardarMovimiento() {
        try {
            mod.setProducto_id(Integer.parseInt(frm.txtProductoId.getText()));
            mod.setTipo_movimientos(frm.cbxTipoMovimiento.getSelectedItem().toString());
            mod.setCantidad_movimientos(Integer.parseInt(frm.txtCantidadMovimientos.getText()));
            mod.setMotivo_movimientos(frm.txtMotivoMovimientos.getText());
            mod.setFecha_movimientos(new Timestamp(new Date().getTime()));
            mod.setUsuario_id(usuarioId);
            
            if (modConsulta.registrar(mod)) {
                JOptionPane.showMessageDialog(frm, "Movimiento registrado");
                limpiarCampos();
                cargarMovimientos();
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(frm, "Error: " + ex.getMessage());
        }
    }
    
    private void cargarMovimientos() {
        try {
            List<ClaseMovimientoInventario> movimientos = modConsulta.obtenerTodos();
            DefaultTableModel modelo = (DefaultTableModel) frm.tblMovimientoInventario.getModel();
            modelo.setRowCount(0);
            
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
            
            for (ClaseMovimientoInventario movimiento : movimientos) {
                modelo.addRow(new Object[]{
                    movimiento.getId_movimientos_inventario(),
                    movimiento.getProducto_id(),
                    movimiento.getTipo_movimientos(),
                    movimiento.getCantidad_movimientos(),
                    movimiento.getMotivo_movimientos(),
                    sdf.format(movimiento.getFecha_movimientos()),
                    movimiento.getUsuario_id()
                });
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(frm, "Error: " + ex.getMessage());
        }
    }
    
    private void actualizarMovimiento() {
        // Implementar lógica de actualización
    }
    
    private void eliminarMovimiento() {
        // Implementar lógica de eliminación
    }
    
    private void limpiarCampos() {
        frm.txtIdMovimientos.setText("");
        frm.txtProductoId.setText("");
        frm.txtCantidadMovimientos.setText("");
        frm.txtMotivoMovimientos.setText("");
        frm.cbxTipoMovimiento.setSelectedIndex(0);
    }
}